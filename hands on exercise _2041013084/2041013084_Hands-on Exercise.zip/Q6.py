A = (int)(input("Enter a number"))
B=(int)(input("Enter another number"))
print("Before Swapping A = ",A," and B = ",B)
A=A+B
B=A-B
A=A-B
print("After Swapping A = ",A," and B = ",B)