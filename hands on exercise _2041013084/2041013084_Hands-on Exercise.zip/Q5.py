A = (int)(input("Enter a number:"))
B=(int)(input("Enter another number:"))
print("Before Swapping A = ",A," and B = ",B)
C=A
A=B
B=C
print("After Swapping A = ",A," and B = ",B)
