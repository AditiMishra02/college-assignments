regNo = (int)(input("Enter reg.no"))
yearOfAdmission=(int)(input("Enter Admission year"))
print("My Regd. No is ",regNo," and I have taken admission in B. Tech. In ",yearOfAdmission)