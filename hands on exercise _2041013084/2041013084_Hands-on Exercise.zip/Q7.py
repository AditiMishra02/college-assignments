ruler1="1"
print(ruler1)
ruler1=ruler1+" 2 "+ruler1
print(ruler1)
ruler1=ruler1+" 3 "+ruler1
print(ruler1)
ruler1=ruler1+" 4 "+ruler1
print(ruler1)