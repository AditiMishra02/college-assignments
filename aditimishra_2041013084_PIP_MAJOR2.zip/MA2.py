#NAME: ADITI MISHRA
#REG.NO.:2041013084
#BRANCH:CSE
#SECTION:P
#PROGRAMMING IN PYTHON MAJOR ASSIGNMENT - 2

import pickle

studentData = {}

#Problem 1:
def problem1():

    student1 = {"name": "ABC","roll": 1001,"marks": {"python_mark": 99,"TOC_mark": 89,"OS_mark": 78}}
    student2 = {"name": "EFG","roll": 1002,"marks": {"python_mark": 69,"TOC_mark": 59,"OS_mark": 48}}
    student3 = {"name": "HIJ","roll": 1003,"marks": {"python_mark": 91,"TOC_mark": 69,"OS_mark": 71}}
    student4 = {"name": "LMN","roll": 1004,"marks": {"python_mark": 89,"TOC_mark": 78,"OS_mark": 67}}
    studentData[1001] = student1
    studentData[1002] = student2
    studentData[1003] = student3
    studentData[1004] = student4
    f = open('StudentFile.txt', 'wb')
    pickle.dump(studentData, f)
    f.close()

#Problem 2:
def problem2():

    f = open('StudentFile.txt', 'rb')
    studentData = pickle.load(f)
    for i in studentData:
        print(i,'=', studentData[i])
    f.close()

#Problem 3,4 and 5:
class Student:
        average_marks = 0
        grade = " "
        def __init__(self, name, roll, python_mark, TOC_mark, OS_mark):
            self.name = name
            self.roll = roll
            self.python_mark = python_mark
            self.TOC_mark = TOC_mark
            self.OS_mark = OS_mark
            self.average_marks=0
            self.grade= " "

        def moderate_marks(self,grace_mark):
            if self.python_mark < 100:
                self.python_mark = self.python_mark + grace_mark
            else:
                self.python_mark = 100

            if self.TOC_mark < 100:
                self.TOC_mark = self.TOC_mark + grace_mark
            else:
                self.TOC_mark = 100

            if self.OS_mark < 100:
                self.OS_mark = self.OS_mark + grace_mark
            else:
                self.OS_mark = 100

            return self.python_mark, self.TOC_mark, self.OS_mark

        def average(self):
           m1, m2, m3 = self.moderate_marks(4)
           average_marks = (m1 + m2 + m3) // 3
           return average_marks

        def get_grade(self):
            markpercentage = self.average()
            if markpercentage < 40:
                self.grade = 'D(Fail)'
            elif markpercentage>=40 and  markpercentage < 60:
                self.grade = 'C'
            elif markpercentage>=60 and  markpercentage < 80:
                self.grade = 'B'
            elif markpercentage>=80:
                self.grade = 'A'
            return self.grade

def main():
    problem1()
    problem2()
    f = open('StudentFile.txt', 'rb')
    studentData = pickle.load(f)
    for i in studentData:
        dict = studentData[i]
        name = dict['name']
        roll = dict['roll']
        PYTHON = dict['marks']['python_mark']
        TOC = dict['marks']['TOC_mark']
        OS = dict['marks']['OS_mark']
        obj = Student(name, roll, PYTHON, TOC, OS)
        print('Grade of',name,'is ',obj.get_grade())
if __name__ == '__main__':
    main()